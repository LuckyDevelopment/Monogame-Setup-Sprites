﻿using var game = new Monogametest.Game1();
game.Run();
