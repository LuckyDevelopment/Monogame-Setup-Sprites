using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Monogametest;

//! This class handles sprites.
public static class SpriteManager
{
    private static List<Sprite> sprites;
    private static SamplerState _samplerState;

    /// <summary>
    /// Internally called to setup sprites.
    /// </summary>
    public static void Setup()
    {
        sprites = new List<Sprite>();
        _samplerState = SamplerState.PointWrap;
    }
    
    /// <summary>
    /// Internally called to update sprites.
    /// </summary>
    /// <param name="gameTime"></param>
    public static void Update(GameTime gameTime)
    {
        if (sprites != null) 
        {
            foreach (Sprite sprite in sprites)
            {
                if (sprite != null)
                    sprite.Update(gameTime);
                else
                    Console.WriteLine("A sprite is null!");
            }
        }
        else
        {
            Console.WriteLine("ERROR: Sprites in SpriteManager are null!");
        }
    }

    /// <summary>
    /// Internally called to draw sprites.
    /// </summary>
    /// <param name="_spriteBatch"></param>
    public static void Draw(SpriteBatch _spriteBatch)
    {
        _spriteBatch.Begin(samplerState: _samplerState);
        if (sprites != null) 
        {
            foreach (Sprite sprite in sprites)
            {
                if (sprite != null)
                    sprite.Draw(_spriteBatch);
                else
                    Console.WriteLine("A sprite is null!");
            }
        }
        else
        {
            Console.WriteLine("ERROR: Sprites in SpriteManager are null!");
        }
        _spriteBatch.End();
    }

    /// <summary>
    /// Set the sampler mode of drawing sprites.
    /// </summary>
    /// <param name="samplerState"></param>
    public static void SetSamplerMode(SamplerState samplerState)
    {
        _samplerState = samplerState;
    }

    /// <summary>
    /// Adds a sprite to the draw queue.
    /// </summary>
    /// <param name="sprite"></param>
    public static void AddSprite(Sprite sprite)
    {
        if (sprites != null) 
        {
            sprites.Add(sprite);
        }
        else
        {
            Console.WriteLine("Sprite not found in the list.");
        }
    }

    /// <summary>
    /// Removes a sprite from the world.
    /// </summary>
    /// <param name="sprite"></param>
    public static void RemoveSprite(Sprite sprite)
    {
        if (sprites != null) 
        {
            if (sprites.Contains(sprite))
            {
                sprites.Remove(sprite); 
            }
            else
            {
                Console.WriteLine("Sprite not found in the list.");
            }
        }
        else
        {
            Console.WriteLine("ERROR: Sprites in SpriteManager are null!");
        }
    }

    /// <summary>
    /// Returns all the sprites in the world.
    /// </summary>
    /// <returns></returns>
    public static List<Sprite> GetSprites()
    {
        return sprites;
    }
}