using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Monogametest;

//! This class handles the core game loop.
public class GameLoop
{
    // Called when the game starts, use to load content.
    Square mySprite;
    public void Preload(ContentManager content)
    {
        Console.WriteLine("Preload");
        mySprite = new Square(new Vector2(0, 0), 50, 50);
        SpriteManager.AddSprite(mySprite);
    }

    // Called when the program initalizes.
    public void Start()
    {
        Console.WriteLine("Start");

        
    }

    // Called every frame.
    public void Update(GameTime gameTime)
    {
        Console.WriteLine("Update");
        mySprite.Width += 1;
    }
}