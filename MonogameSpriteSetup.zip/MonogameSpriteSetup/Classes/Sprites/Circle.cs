using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Monogametest;

//! This class is a base Sprite class.
public class Circle : Sprite
{
    // Privates
    private static Texture2D _circleTexture;
    private int _radius;

    private static Texture2D circleTexture
    {
        get {
            if (_circleTexture == null)
            {
                _circleTexture = Game1.game.Content.Load<Texture2D>("Circle");
            }
            return _circleTexture;
        }
        set {
            _circleTexture = value;
        }
    }

    // Publics
    public int Radius 
    {
        get { return _radius; }
        set { _radius = value;  Width = value * 2; Height = value * 2; if (CenterPivot) { _offset = new Vector2(_width / 2, _height / 2); } }
    }


    /// <summary>
    /// Creates new circle sprite.
    /// </summary>
    /// <param name="position"></param>
    /// <param name="radius"></param>
    public Circle(Vector2 position, int radius) : base(circleTexture, position, radius * 2, radius * 2)
    {
        this.CenterPivot = true;
    }
}