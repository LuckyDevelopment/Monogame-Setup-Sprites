using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Monogametest;

//! This class is a base Sprite class.
public class Square : Sprite
{
    // Privates
    private static Texture2D _squareTexture;
    private static Texture2D squareTexture
    {
        get {
            if (_squareTexture == null)
            {
                _squareTexture = Game1.game.Content.Load<Texture2D>("Square");
            }
            return _squareTexture;
        }
        set {
            _squareTexture = value;
        }
    }

    /// <summary>
    /// Creates new square sprite.
    /// </summary>
    /// <param name="position"></param>
    /// <param name="width"></param>
    /// <param name="height"></param>
    public Square(Vector2 position, int width, int height) : base(squareTexture, position, width, height)
    { }
}