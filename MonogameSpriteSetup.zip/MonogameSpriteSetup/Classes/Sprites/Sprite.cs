using System;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

//! This class is a base Sprite class.
public class Sprite
{
    // Protected Variables
    protected Vector2 _position;
    protected Texture2D _texture;
    protected Color _tint;
    protected int _width;
    protected int _height;
    protected float _scale;
    protected Rectangle _rectangle;
    protected Vector2 _offset;
    protected Boolean _centerPivot;

    // Public Variables
    public Texture2D Texture
    {
        get
        {
            return _texture;
        }
    }

    public Vector2 Position
    {
        get
        {
            return _position;
        }

        set
        {
            _position = value;
            UpdateSpriteSource();
        }
    }

    public float Scale
    {
        get
        {
            return _scale;
        }

        set
        {
            _scale = value;
            UpdateSpriteSource();
        }
    }

    public int Width
    {
        get
        {
            return _width;
        }

        set
        {
            _width = value;
            UpdateSpriteSource();
        }
    }

    public int Height
    {
        get
        {
            return _height;
        }

        set
        {
            _height = value;
            UpdateSpriteSource();
        }
    }

    public Color Tint
    {
        get
        {
            return _tint;
        }

        set
        {
            _tint = value;
            UpdateSpriteSource();
        }
    }

    public Boolean CenterPivot
    {
        get 
        {
            return _centerPivot;
        }

        set
        {
            _centerPivot = value;
            if (_centerPivot)
            {     
                _offset = new Vector2(_width / 2, _height / 2);
            }
            else
            {
                _offset = Vector2.Zero;
            }
            UpdateSpriteSource();
        }
    }

    /// <summary>
    /// Creates a new sprite object.
    /// </summary>
    /// <param name="texture"></param>
    /// <param name="position"></param>
    /// <param name="width"></param>
    /// <param name="height"></param>
    public Sprite(Texture2D texture, Vector2 position, int width, int height)
    {
        this._texture = texture;
        this._position = position;
        this._width = width;
        this._height = height;
        this._scale = 1f;
        this._tint = Color.White;
        this._offset = Vector2.Zero;

        UpdateSpriteSource();
    }

    /// <summary>
    /// Creates a new Sprite object.
    /// </summary>
    /// <param name="texture"></param>
    /// <param name="position"></param>
    /// <param name="scale"></param>
    public Sprite(Texture2D texture, Vector2 position, float scale = 1.0f)
    {
        this._texture = texture;
        this._position = position;
        this._width = texture.Width;
        this._height = texture.Height;
        this._scale = scale;
        this._tint = Color.White;
        this._offset = Vector2.Zero;

        UpdateSpriteSource();
    }

    /// <summary>
    /// When editing the sprites member variables, call this to update the source. This should be automatically called so you shouldn't have to worry about this.
    /// </summary>
    public void UpdateSpriteSource()
    {
        this._rectangle = new Rectangle((int)(this._position.X - this._offset.X), (int)(this._position.Y - this._offset.Y), (int)(this._width * this._scale), (int)(this._height * this._scale));
    }

    /// <summary>
    /// Can be overridden for custom draw features.
    /// </summary>
    /// <param name="_spriteBatch"></param>
    public virtual void Draw(SpriteBatch _spriteBatch)
    {
        if (_texture == null) {Console.WriteLine("A sprite has a null texture. Not currently drawing it."); return; }
        _spriteBatch.Draw(this._texture, this._rectangle, this._tint);
    } 

    /// <summary>
    /// Meant to be overriden for items like bullets.
    /// </summary>
    /// <param name="gameTime"></param>
    public virtual void Update(GameTime gameTime)
    {

    }

    /// <summary>
    /// Moves the sprite by certain pixels.
    /// </summary>
    /// <param name="x"></param>
    /// <param name="y"></param>
    public void Move(int x, int y = 0)
    {
        this.Position = new Vector2(this._position.X + x, this._position.Y + y);
    }

    /// <summary>
    /// Moves the sprite to a new position via pixels.
    /// </summary>
    /// <param name="x"></param>
    /// <param name="y"></param>
    public void SetPosition(int x, int y)
    {
        this.Position = new Vector2(x, y);
    }

    /// <summary>
    /// Removes the sprite from the world.
    /// </summary>
    public void Destroy()
    {
        SpriteManager.RemoveSprite(this);
    }
}