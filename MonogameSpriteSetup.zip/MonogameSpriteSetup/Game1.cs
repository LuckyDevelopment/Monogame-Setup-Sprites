﻿using System.Collections.Generic;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Monogametest;

public class Game1 : Game
{
    // Privates
    private GraphicsDeviceManager _graphics;
    private SpriteBatch _spriteBatch;
    private GameLoop gameLoop;

    // Publics
    public static Game1 game;
    public SamplerState sampler;

    public Game1()
    {
        _graphics = new GraphicsDeviceManager(this);
        Content.RootDirectory = "Content";
        IsMouseVisible = true;
        SpriteManager.Setup();
        gameLoop = new GameLoop();
        Game1.game = this;
        sampler = SamplerState.PointClamp;
    }

    protected override void Initialize()
    {
        gameLoop.Start();

        base.Initialize();
    }

    protected override void LoadContent()
    {
        _spriteBatch = new SpriteBatch(GraphicsDevice);

        gameLoop.Preload(this.Content);
    }

    protected override void Update(GameTime gameTime)
    {
        if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed || Keyboard.GetState().IsKeyDown(Keys.Escape))
            Exit();

        gameLoop.Update(gameTime);

        SpriteManager.Update(gameTime);

        base.Update(gameTime);
    }

    protected override void Draw(GameTime gameTime)
    {
        GraphicsDevice.Clear(Color.Black);

        SpriteManager.Draw(_spriteBatch);

        base.Draw(gameTime);
    }
}
